// require
const express = require('express'),
    bodyParser = require('body-parser'),
    mongoose = require('mongoose'),
    app = express();

// use
app.use(bodyParser.urlencoded({ extended: true}));
app.use(bodyParser.json());

// connect    
mongoose.connect('mongodb://localhost/restTasksAPI', { useNewUrlParser: true});

// mongoose
require('./server/config/mongoose');

// routes
require('./server/config/routes')(app);


// server listen
app.listen(8000, function() {
    console.log('listening on port 8000');
})

